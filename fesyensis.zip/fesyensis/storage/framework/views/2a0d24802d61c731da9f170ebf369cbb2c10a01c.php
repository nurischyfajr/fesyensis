<?php $__env->startSection('content'); ?>




    <div class="col-xs-12 no-padding">
        <div class="headline-cordova">
            Narumi Kids
        </div>

        <div class="subheadline-cordova">
            Mainan yang dapat melatih kemampuan berbicara anak sekaligus menjadi teman bermain anak saat bosan dirumah.

            
            
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center" style="margin-top:15px !important;">
        <iframe width="100%" height="315" src="https://www.youtube.com/embed/Qq1OQH8RQTU" frameborder="0"
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
    </div>

    <div class="col-xs-12 no-padding">
        <div class="title-kelebihan-cordova">
            Kenapa harus Narumi Kids?
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center value-cordova">
        <div class="headline-kelebihan-cordova">
            ✅ Merangsang Kemampuan Berbicara
        </div>

        <div class="subheadline-kelebihan-cordova">
            Boneka ini menerima suara disekitarnya dan meniru dengan suara menggemaskan, membuat anak Bunda ingin
            membalasnya, sehingga anak Bunda jadi aktif berbicara👌
        </div>

        <div class="headline-kelebihan-cordova">
            ✅ Menghilangkan Rasa Bosan & Menghibur
        </div>

        <div class="subheadline-kelebihan-cordova">
            Di kondisi Covid-19 ini mengharuskan semua orang dirumah sehingga anak Bunda akan merasa bosan dirumah,
            boneka ini dapat
            menghilangkan rasa bosan itu dengan mengeluarkan suara yang sangat menggemaskan.
        </div>


        <div class="headline-kelebihan-cordova">
            ✅ Melatih Saraf Anak
        </div>

        <div class="subheadline-kelebihan-cordova">
            Anak Bunda akan sangat senang melihat boneka yang bergerak-gerak & mendengar suara yang dikeluarkan oleh
            boneka ini dan merespon terhadap apa yang dia dengar
        </div>


        <div class="headline-kelebihan-cordova">
            ✅ Bahan Aman
        </div>

        <div class="subheadline-kelebihan-cordova">
            Kulit boneka terbuat dari bahan yang sangat lembut dan aman untuk digigit, jadi Bunda gaperlu khawatir
        </div>

        <div class="headline-kelebihan-cordova">
            ✅ Bisa Bayar di tempat (COD)
        </div>


        <div class="subheadline-kelebihan-cordova">
            Bunda bisa bayar di tempat setelah barang sampai😊
        </div>

    </div>


    <div class="col-xs-12 no-padding text-center" style="margin-top: 20px !important;">
        
        

        <img src="https://scontent.fcgk9-1.fna.fbcdn.net/v/t1.0-9/94785240_151788096347121_2827931253666217984_n.jpg?_nc_cat=102&_nc_sid=8024bb&_nc_eui2=AeGtwIt39_8b4IT-d5RScd5YMruHSVLiUBUyu4dJUuJQFUXG91zOK2DJQmN5CncXi8ppfz4YST1Pg_nm-STFLYod&_nc_ohc=jWfhIBfGEf4AX8Qxv5I&_nc_ht=scontent.fcgk9-1.fna&oh=c06aca2a3a7775f44dfd304322fdd8b2&oe=5ECE7AA8"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk9-2.fna.fbcdn.net/v/t1.0-9/94886127_151788149680449_983749563225473024_n.jpg?_nc_cat=101&_nc_sid=8024bb&_nc_eui2=AeFChY-tEgerD03RgLuQ3xsLFLMesNsh3D8Usx6w2yHcP1dvlPrOa1Cuk2rt9NNNJUFJkXJH2LWwkK9xLIdN777Y&_nc_ohc=dFY3HNWla1cAX8kZnKH&_nc_ht=scontent.fcgk9-2.fna&oh=8b50b815c1b43d93d7ec40c42001064f&oe=5ECDC6CC"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk8-2.fna.fbcdn.net/v/t1.0-9/94684260_151788123013785_8647409440628146176_n.jpg?_nc_cat=109&_nc_sid=8024bb&_nc_eui2=AeECm_17Zban_R9Hw-3XR51OpAZu9SZ4a-akBm71Jnhr5oOiFJ8HLJ3M1srGcWRrrT2OktePQjxfMtYxUaouOmrD&_nc_ohc=q_WEUS_E1loAX-bwxjy&_nc_ht=scontent.fcgk8-2.fna&oh=5115add1c2c47a02ac51474fc77843f5&oe=5ECF4A19"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk8-1.fna.fbcdn.net/v/t1.0-9/94882998_151788169680447_2790119495463600128_n.jpg?_nc_cat=108&_nc_sid=8024bb&_nc_eui2=AeHrfcfdJhgVAb7zvxJQmRV6hs7RYVojK4aGztFhWiMrhkbp8Npq8zWgZ_9JikUBFVxd6b81TsQWmt5RydPfRea2&_nc_ohc=23qBa1my_LwAX81ljde&_nc_ht=scontent.fcgk8-1.fna&oh=b290db0908070e29ec3794e713905326&oe=5ECD83B7"
             class="image-detail" alt="">




    </div>



    <div class="col-xs-12 no-padding">
        <div class="headline-promo-cordova">
            PROMO SPESIAL HANYA HARI INI
        </div>

        <div class="normal-price-cordova">
            Harga Normal
        </div>
        <div class="normal-price-cordova normal-price">
            <del>
                Rp. 250.000
            </del>
        </div>

        <div class="border-promo-price-cordova">
            <div class="text-promo-price-cordova">
                Harga Promo
            </div>

            <div class="price-promo-price-cordova">
                RP. 79.000
            </div>

            <div class="desc-price-promo-price-cordova">
                ( Bisa Bayar di Tempat )
            </div>
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center">
        <img src="https://i2.wp.com/audinaindonesia.com/wp-content/uploads/2019/04/panah-1.gif?zoom=2&fit=478%2C239&ssl=1"
             class="img-responsive" style="margin: 20px auto;"
             alt="">
    </div>

    <div class="col-xs-12" style="margin-bottom:40px;">
    </div>

    
    
    
    
    
    
    
    
    

    
    
    
    
    


    <div class="col-xs-12 float-bottom-button">
        <a href="https://api.whatsapp.com/send?phone=6285156961252&text=Halo%20ka,%20saya%20tertarik%20PROMO%20Narumi%20Kids%20nya,%20mohon%20infonya%20ya%20ka"
           class="float-button">
            <img src="<?php echo e(asset('image/icon/whatsapp.png')); ?>"
                 style="width:30px;"
                 alt="">
            Ambil Promonya(Bisa COD)
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>