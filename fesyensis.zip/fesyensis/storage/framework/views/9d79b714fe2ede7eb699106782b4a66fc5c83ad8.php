<?php $__env->startSection('content'); ?>




    <div class="col-xs-12 no-padding">
        <div class="headline-cordova">
            Kotak Makan Original
        </div>

        <div class="subheadline-cordova">
            Anti Tumpah dan Anti Campur
        </div>
    </div>


    <div class="col-xs-12 no-padding">
        <img src="https://dapurcordova.com/shop/wp-content/uploads/2018/11/6.jpeg"
             class="img-responsive image-headline" alt="">
    </div>

    <div class="col-xs-12 no-padding">
        <div class="title-kelebihan-cordova">
            KENAPA HARUS KOTAK MAKAN ANTI TUMPAH INI?
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center value-cordova">
        <div class="headline-kelebihan-cordova">
            ✅ Anti Tumpah & Anti Campur.
        </div>

        <div class="subheadline-kelebihan-cordova">
        kakak gak perlu khawatir kalau bawa bekal berkuah, pakai lunchbox ini dijamin kuah tidak akan bercampur dan
        tumpah keluar karena ada pelindung anti tumpahnya👌
        </div>


        <div class="headline-kelebihan-cordova">
            ✅ FREE ONGKIR
        </div>

        
        
        
        <div class="subheadline-kelebihan-cordova">
        Kita juga lagi ada promo <b>FREE ONGKIR</b> khusus Hari ini😊
        </div>

        <div class="headline-kelebihan-cordova">
            ✅ Bisa Bayar di tempat (COD)
        </div>


        <div class="subheadline-kelebihan-cordova">
        kakak bisa bayar di tempat setelah barang sampai😊
        </div>

        <div class="headline-kelebihan-cordova">
            ✅ Bahan Tebal dan Aman
        </div>

        <div class="subheadline-kelebihan-cordova">
        bahan dari plastik PP 05 food grade yang bersertifikat BPA FREE sehingga aman digunakan untuk makanan dan
        tidak mengganggu kesehatan👍🏻
        </div>


        <div class="headline-kelebihan-cordova">
            ✅ Tidak mudah Basi
        </div>


        <div class="subheadline-kelebihan-cordova">
        kakak gak perlu khawatir makanan basi karena lunchbox ini kedap udara sehingga makanan tidak mudah basi.
        ukuran kotak makan ini juga sangat ideal sehingga bisa dimasukan ke tas dan dibawa kemana mana🙆‍
        </div>


    </div>


    <div class="col-xs-12 no-padding text-center" style="margin-top: 20px !important;">
        
        

        <img src="https://scontent.fcgk9-1.fna.fbcdn.net/v/t1.0-9/82181972_116801763179088_6218878504465858560_n.jpg?_nc_cat=105&_nc_eui2=AeEWsezlkrXwrrKAagQRV1k36t6zGoyHlF6JlHmGR3UUcr96KB6LKK-bSN8-m74M4DpnUYmep30xXuPywI4Ubf_uei1DsLnbNlRT8XofrhWOEA&_nc_ohc=asaujPoMyg4AX_rkqgY&_nc_ht=scontent.fcgk9-1.fna&oh=068b47d9e468623718cdbf4e0221b561&oe=5E8EEE71"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk9-1.fna.fbcdn.net/v/t1.0-9/p960x960/82818760_116676979858233_6536479456125517824_o.jpg?_nc_cat=110&_nc_eui2=AeECX8_nnnuoWYUDywRc3tvUEtHOFmW0U4hqlhac1hCesBuprbHaRPEElE9bkf0bQLQfTbPqqjz4Gs-gehTjW4l1j0D__7dUs8uqxhuLuJpSGw&_nc_ohc=Z86c8k19vV4AX9679CV&_nc_ht=scontent.fcgk9-1.fna&_nc_tp=1002&oh=666f34591b15b1eed0bc293215cad86a&oe=5E97E972"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk8-1.fna.fbcdn.net/v/t1.0-9/83324072_116677216524876_1258232071185235968_o.jpg?_nc_cat=108&_nc_eui2=AeGouNX8rbB2LQxkJzsupTJ3aKb1L82l3NV9AQD4UNb4kY-hcefslz8fT90ktm2bRrL8B6WsqQAR1tEpkB99oMtnvoXMqR-jsf3Bwv_TxOJ_9A&_nc_ohc=gUv6gqsa_5gAX-fqGCO&_nc_ht=scontent.fcgk8-1.fna&oh=a433daa47c15782092dda1565938101c&oe=5ED5E75C"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk9-1.fna.fbcdn.net/v/t1.0-9/p960x960/81970989_110992187093379_9190050950427967488_o.jpg?_nc_cat=105&_nc_eui2=AeGu4riyXhhWRQ3mRAsCbz8yRPrGV8vLSigYsc2ees1I4WuE3CB8-7tufyPRVoUKuOXZklGxmuuo0Vj_COz7EkVqHvuiQ78jIl91G1mOkS8klA&_nc_ohc=mi2jpOcqQF0AX8_ac6u&_nc_ht=scontent.fcgk9-1.fna&_nc_tp=1002&oh=59e0fe22e2102754a73f4d2795e9249f&oe=5EA3E257"
             class="image-detail" alt="">

    </div>


    <div class="col-xs-12 no-padding text-center">
        <iframe width="100%" height="315" src="https://www.youtube.com/embed/muoHppn9bMU" frameborder="0"
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
    </div>

    <div class="col-xs-12 no-padding">
        <div class="headline-promo-cordova">
            PROMO SPESIAL HARI INI
        </div>

        <div class="normal-price-cordova">
            Harga Normal
        </div>
        <div class="normal-price-cordova normal-price">
            <del>
                Rp. 250.000
            </del>
        </div>

        <div class="border-promo-price-cordova">
            <div class="text-promo-price-cordova">
                Harga Promo
            </div>

            <div class="price-promo-price-cordova">
                RP. 99.000
            </div>

            <div class="desc-price-promo-price-cordova">
                ( Bisa COD & FREE ONGKIR )
            </div>
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center">
        <img src="https://i2.wp.com/audinaindonesia.com/wp-content/uploads/2019/04/panah-1.gif?zoom=2&fit=478%2C239&ssl=1"
             class="img-responsive" style="margin: 20px auto;"
             alt="">
    </div>

    <div class="col-xs-12" style="margin-bottom:40px;">
    </div>

    
    
    
    
    
    
    
    
    

    
    
    
    
    


    <div class="col-xs-12 float-bottom-button">
        <a href="https://api.whatsapp.com/send?phone=6285794411846&text=Halo%20ka,%20Saya%20tertarik%20PROMO%20*kotak%20makan%20original%20ANTI%20TUMPAH*,%20mohon%20infonya%20ya.%20"
           class="float-button">
            <img src="<?php echo e(asset('image/icon/whatsapp.png')); ?>"
                 style="width:30px;"
                 alt="">
            Ambil Promonya(Bisa COD)
        </a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>