<?php $__env->startSection('content'); ?>




    <div class="col-xs-12 no-padding">
        <div class="headline-announcement-parfumislami">
            <span class="color-ff0000">
                PROMO SPESIAL
            </span>
            <br>
            DISKON 50% & BISA COD
            <br>
            <span class="color-ff0000">
                BELI 1 DAPAT 3 PARFUM
            </span>
        </div>
    </div>

    <div class="col-xs-12 no-padding">
        <div class="headline-parfumislami">
            <span class="color-ff0000">
                Inilah Parfum Best Seller
            </span>
            yang Wanginya
            <span class="color-ff0000">
                Tahan Lama,
            </span>
            <br>
            Harumnya

            <span class="color-ff0000">
                Lembut
            </span>
            &
            <span class="color-ff0000">
                Tanpa Alkohol
            </span>
        </div>
    </div>

    <div class="col-xs-12 no-padding">
        <img src="https://parfumislami.org/wp-content/uploads/2019/12/top-1-768x432-1.png" style="width: 100%;">
        <div class="title-image-parfumislami">
            Parfum Favorit Ustadzah Oki Setiana Dewi
        </div>
    </div>

    <div class="col-xs-12 no-padding">
        <div style="height: 2px; width: 90%; margin: 35px auto; background-color: black;"></div>
    </div>

    <div class="col-xs-12 no-padding">
        <div style="">
            <ul>
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Pembayaran di tempat(COD)
                    </span>
                </li>
            </ul>
            <ul class="list-option">
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        AMAN, HALAL, NON ALKOHOL
                    </span>
                </li>
            </ul>
            <ul>
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Aman digunakan saat beribadah & shalat
                    </span>
                </li>
            </ul>
            <ul>
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Lebih di Sayang Suami dirumah
                    </span>
                </li>
            </ul>

            <ul>
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Membuat tampil lebih santai dan elegan
                    </span>
                </li>
            </ul>
            <ul class="list-option">
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Aroma Wangi Segar ​& Exclusive
                    </span>
                </li>
            </ul>
            <ul>
                <li class="glyphicon glyphicon-ok">
                    <span class="list-option-ul-checklist-parfumislami">
                        Aroma Wangi Manis dengan perpaduan sari bunga & buah-buahan pilihan
                    </span>
                </li>
            </ul>

        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>