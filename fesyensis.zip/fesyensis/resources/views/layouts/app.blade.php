<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

{{--    <title>{{ config('app.name', 'Cordova Store') }}</title>--}}
    <title>Daster Fesyensis - Promo Hari ini</title>


    <link rel="icon"
          href="https://scontent-cgk1-1.xx.fbcdn.net/v/t1.0-9/81536113_1040627952984373_1174979365717409792_o.jpg?_nc_cat=102&_nc_eui2=AeES6dK1fBsRtL5z-02NhHPh7qCUAdBS6wwZO6Dn7F5fEgoSbSsy32ftWvNZrIRobkmKFeBWC0vFsFDqUbmfz8jkEU3Mq_m0rQjKUmv9QW9sNA&_nc_ohc=tgYK9LmF4o4AX_HMGhd&_nc_ht=scontent-cgk1-1.xx&oh=fc76d18f66568b0d02d73892be0c554d&oe=5ED764B3">


    <!-- Styles -->
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <link href="{{ asset('css/responsive.css') }}" rel="stylesheet">
    <link href="{{ asset('css/utility.css') }}" rel="stylesheet">
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
    <link href="{{ asset('css/font.css') }}" rel="stylesheet">

    <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css"
          as="style" onload="this.rel='stylesheet'" media="all">
    <noscript>
        <link rel="stylesheet"
              href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" media="all">
    </noscript>


    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '2833845400027374');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
                   src="https://www.facebook.com/tr?id=2833845400027374&ev=PageView&noscript=1"
        /></noscript>
    <!-- End Facebook Pixel Code -->

</head>
<body style="max-width: 640px;margin: auto; background-color: #e8e8e8;">

<div id="app">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no-padding"
         style="background-color: white; width: 100%; height: auto; padding-bottom: 20px !important;">
        @yield('content')
    </div>
</div>

<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
