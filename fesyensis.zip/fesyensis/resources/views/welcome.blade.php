@extends('layouts.app')

@section('content')




    <div class="col-xs-12 no-padding" style="background-color: #FFCDD2; padding-top: 15px; padding-bottom: 15px;">
        <div class="headline-cordova">
            Beli Daster Tapi Bahannya <br><span class="border-title">Panas</span> dan Bikin <span class="border-title">Gerah?</span>
        </div>
        <div class="headline-cordova">
            Inilah Daster Best Seller yang Bahannya <br> <span class="border-title">Adem</span> dan <span
                    class="border-title">Sejuk</span>
        </div>
    </div>


    <div class="col-xs-12 no-padding text-center" style="margin-top: 20px !important;">
        <img src="https://scontent.fcgk8-2.fna.fbcdn.net/v/t1.0-9/97515226_100573968338928_7929688815982084096_n.jpg?_nc_cat=107&_nc_sid=8024bb&_nc_eui2=AeEDPGE8MdSQ9OUQ_w_l6PVFU4Uc7QPULotThRztA9Quiy_7d2rwPPJcXAM2--A2n-WFAnkpDgDuboFE6vTHsor8&_nc_ohc=X3pdV3Zg-QcAX9A6ZDe&_nc_ht=scontent.fcgk8-2.fna&oh=2195c3c1bafff5c7bf7a57beda1fa485&oe=5EE55960"
             class="image-detail" alt="">
    </div>

    <div class="col-xs-12 no-padding">
        <div class="value-cordova subheadline-kelebihan-fesyen">
            Daster Verona adalah daster yang dibuat dari bahan rayon <br> yang lembut
            <br>
            <div style="margin-top: 7px;"></div>
            Daster ini siap menjadi teman beraktivitas buat kamu tetap adem seharian👌
        </div>
    </div>


    <div class="col-xs-12 no-padding text-center" style="margin-top: 20px !important;">
        <img src="https://scontent.fcgk8-1.fna.fbcdn.net/v/t1.0-9/96794692_100519675011024_3312340286901846016_n.jpg?_nc_cat=111&_nc_sid=e007fa&_nc_eui2=AeHMYtdePN8yW6Ui69kJcXDMpSwOWNKhI2ilLA5Y0qEjaPekE5838yoU09akoGMNVYt0AJk0jUvxdn_aVN2_yV67&_nc_ohc=37Zt5art2p0AX8T6M6x&_nc_ht=scontent.fcgk8-1.fna&oh=839d1f337cded10df7edfdc8608d8f3d&oe=5EE6CC48"
             class="image-detail" alt="">
    </div>

    <div class="col-xs-12 no-padding">
        <div class="title-kelebihan-cordova">
            Kenapa harus Daster Verona?
        </div>
    </div>

    <div class="col-xs-12 no-padding value-cordova">
        <div class="headline-kelebihan-cordova">
            ✅ Bahan Rayon Kualitas Terbaik
            <br>
            ✅ Nyaman Dipakai
            <br>
            ✅ Tidak Luntur
            <br>
            ✅ Bahan Adem/ Tidak Panas
            <br>
            ✅Ukuran lingkar dada 110 cm
            <br>
            ✅Panjang 110 cm
            <br>
            ✅ Bisa Bayar di tempat (COD)
        </div>
        <div class="headline-kelebihan-cordova">

        </div>


    </div>


    <div class="col-xs-12 no-padding text-center" style="margin-top: 20px !important;">

        <img src="https://scontent.fcgk9-2.fna.fbcdn.net/v/t1.0-9/96829992_100519665011025_3885566443500077056_n.jpg?_nc_cat=103&_nc_sid=e007fa&_nc_eui2=AeHhH9Es7Hmh5R0bh9kVgDVk9PcVl7agSiT09xWXtqBKJFLyW-ITUzaqSaOuFpgun5FSDetiFpG0cbBYTW_F6HcI&_nc_ohc=7o7cCq1qGisAX-c3gSK&_nc_ht=scontent.fcgk9-2.fna&oh=4bcbc6d96df5435b2998c8caf1737d53&oe=5EE670A1"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk9-2.fna.fbcdn.net/v/t1.0-9/96774015_100519688344356_7850707936526467072_n.jpg?_nc_cat=104&_nc_sid=e007fa&_nc_eui2=AeHJ77LdKwlpF2takzSaHP6yyKLb17uHREzIotvXu4dETA3W4PU4JuMSu6V9wkFm7qsqStESzC32cRMVMD6pkxFV&_nc_ohc=UnVT9VEIOB8AX_zieyk&_nc_ht=scontent.fcgk9-2.fna&oh=328e9f0546b01361e0a24d94139ca2d1&oe=5EE6A7DC"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk8-2.fna.fbcdn.net/v/t1.0-9/97396868_100519771677681_4328112022479699968_n.jpg?_nc_cat=107&_nc_sid=e007fa&_nc_eui2=AeEsU5LOSwwpayNAVYxvtThGh-2MssjdGLqH7YyyyN0Yuo632BHtp5mWRZdgHzoG-AzmCRzQiYGFRBX4LZcudQmv&_nc_ohc=T32QsfZeLA8AX_P08bL&_nc_ht=scontent.fcgk8-2.fna&oh=56727fb813d94765c91888e6cef6e9de&oe=5EE5FF4F"
             class="image-detail" alt="">

        <img src="https://scontent.fcgk9-1.fna.fbcdn.net/v/t1.0-9/96889354_100519765011015_5734270403791028224_n.jpg?_nc_cat=102&_nc_sid=e007fa&_nc_eui2=AeFY9sGqx1VIGopkd8mMgFSyIyzVvoK5mCcjLNW-grmYJzw8pq1EJA6WfVgoVnlrrjMX_UQ4-2Hmogm2N_BpKFG4&_nc_ohc=Efs7POMkpiIAX-thURB&_nc_ht=scontent.fcgk9-1.fna&oh=cdd6dfd277d6fe41b70d5316dc50dd16&oe=5EE58689"
             class="image-detail" alt="">

{{--        <img src="https://scontent.fcgk8-1.fna.fbcdn.net/v/t1.0-9/97008780_100519605011031_9093614847140036608_n.jpg?_nc_cat=111&_nc_sid=e007fa&_nc_eui2=AeH5YyrXUHicLvdOY9RJC_Dq60eZNwqRvovrR5k3CpG-i7zONLHY75E0o75RrA3Z2WeugM7QL6bXv0Ge7_TMPClh&_nc_ohc=l-1cmQ42eMAAX82F_bP&_nc_ht=scontent.fcgk8-1.fna&oh=eb01ac38f41d548800cfe54f49c15200&oe=5EE373C6"--}}
{{--             class="image-detail" alt="">--}}

    </div>



    <div class="col-xs-12 no-padding">
        <div class="headline-promo-cordova">
            PROMO SPESIAL HANYA HARI INI
        </div>

        <div class="normal-price-cordova">
            Harga Normal
        </div>
        <div class="normal-price-cordova normal-price">
            <del>
                Rp. 165.000
            </del>
        </div>

        <div class="border-promo-price-cordova">
            <div class="text-promo-price-cordova">
                Harga Promo
            </div>

            <div class="price-promo-price-cordova">
                RP. 75.000
            </div>

            <div class="desc-price-promo-price-cordova">
                ( Bisa Bayar di Tempat )
            </div>
        </div>
    </div>

    <div class="col-xs-12 no-padding text-center">
        <img src="https://i2.wp.com/audinaindonesia.com/wp-content/uploads/2019/04/panah-1.gif?zoom=2&fit=478%2C239&ssl=1"
             class="img-responsive" style="margin: 20px auto"
             alt="">
    </div>


    <div class="col-xs-12 no-padding text-center" >
        <img src="http://img.bdjkt.com/img/600/bf143ygmbf146o0msv/x9okrb1WXGiooQgCZ4grURcM.jpg"
             class="image-detail" alt="" style="margin-bottom: 30px;">
    </div>


    <div class="col-xs-12" style="margin-bottom:40px;">
    </div>

    {{--<div class="col-xs-12 no-padding text-center" style="margin-top: 30px !important;">--}}
    {{--<a href="https://api.whatsapp.com/send?phone=6285794411846&text=Halo%20ka,%20Saya%20tertarik%20PROMO%20*kotak%20makan%20original%20ANTI%20TUMPAH*,%20mohon%20infonya%20ya.%20"--}}
    {{--class="button-click-cart">--}}
    {{--<img src="https://www.freeiconspng.com/uploads/icono-whatsapp-red-social-de-flat-gradient-social-icons-22.png"--}}
    {{--style="width:30px;"--}}
    {{--alt="">--}}
    {{--Klik Disini & Ambil Promonya--}}
    {{--</a>--}}
    {{--</div>--}}

    {{--<div class="col-xs-12 no-padding">--}}
    {{--<div class="text-under-button">--}}
    {{--*Promo Terbatas jangan sampai kehabisan--}}
    {{--</div>--}}
    {{--</div>--}}


    <div class="col-xs-12 float-bottom-button">
        <a href="https://api.whatsapp.com/send?phone=6285894713402&text=Halo%20sis,%20saya%20tertarik%20PROMO%20Daster%20Verona%20nya,%20mohon%20infonya%20ya%20sis"
           class="float-button">
            <img src="{{ asset('image/icon/whatsapp.png') }}"
                 style="width:30px;"
                 alt="">
            Ambil Promonya(Bisa COD)
        </a>
    </div>


@endsection
